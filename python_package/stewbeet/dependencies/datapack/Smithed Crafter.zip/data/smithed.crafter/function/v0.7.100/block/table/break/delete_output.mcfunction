
execute if score #killed_output smithed.data matches 1 run return 0

data modify storage smithed.crafter:main temp.output_item_temp set from storage smithed.crafter:main temp.output_item
data modify storage smithed.crafter:main temp.current_item set from entity @s Item
data remove storage smithed.crafter:main temp.current_item.components."minecraft:written_book_content"
execute store success score @s smithed.data run data modify storage smithed.crafter:main temp.output_item_temp set from storage smithed.crafter:main temp.current_item
execute if score @s smithed.data matches 0 run scoreboard players set #killed_output smithed.data 1
kill @s[scores={smithed.data=0}]

