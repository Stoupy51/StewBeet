execute as @e[tag=smithed.crafter] at @s run function smithed.crafter:v0.7.100/block/table/tick

schedule function smithed.crafter:v0.7.100/technical/tick 1 replace
