execute as @a at @s run function smithed.crafter:v0.8.1/entity/player/slow_tick

schedule function smithed.crafter:v0.8.1/technical/slow_tick 5 replace
