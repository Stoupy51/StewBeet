# @public

execute if entity @s[tag=smithed.crafter] run function smithed.crafter:v0.7.100/block/table/tick
