# @public

execute if data storage smithed.custom_block:main {blockApi: {id: "smithed:crafter"}} run function smithed.crafter:v0.7.100/block/table/place
