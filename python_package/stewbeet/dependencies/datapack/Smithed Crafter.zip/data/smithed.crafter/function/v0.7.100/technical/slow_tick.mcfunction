execute as @a at @s run function smithed.crafter:v0.7.100/entity/player/slow_tick

schedule function smithed.crafter:v0.7.100/technical/slow_tick 5 replace
