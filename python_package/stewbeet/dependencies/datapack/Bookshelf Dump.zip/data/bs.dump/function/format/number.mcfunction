# ------------------------------------------------------------------------------------------------------------
# Copyright (c) 2025 Gunivers
#
# This file is part of the Bookshelf project (https://github.com/mcbookshelf/bookshelf).
#
# This source code is subject to the terms of the Mozilla Public License, v. 2.0.
# If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
#
# Conditions:
# - You may use this file in compliance with the MPL v2.0
# - Any modifications must be documented and disclosed under the same license
#
# For more details, refer to the MPL v2.0.
# ------------------------------------------------------------------------------------------------------------

data modify storage bs:data dump.char set string storage bs:data dump.value -1
execute unless data storage bs:data dump{char:"b"} \
  unless data storage bs:data dump{char:"s"} \
  unless data storage bs:data dump{char:"l"} \
  unless data storage bs:data dump{char:"f"} \
  unless data storage bs:data dump{char:"d"} \
  run data remove storage bs:data dump.char

execute if data storage bs:data dump.char run data modify storage bs:data dump.value set string storage bs:data dump.value 0 -1
$loot replace entity B5-0-0-0-3 contents loot {pools:[{rolls:1,entries:[{type:"item",name:"egg",functions:[{function:"set_name",entity:"this",name:[{storage:"bs:data",nbt:"dump.value",color:"$(number)"},{storage:"bs:data",nbt:"dump.char",color:"$(type)"}]}]}]}]}
data modify storage bs:data dump.out append from entity B5-0-0-0-3 item.components.minecraft:custom_name
