# ------------------------------------------------------------------------------------------------------------
# Copyright (c) 2025 Gunivers
#
# This file is part of the Bookshelf project (https://github.com/mcbookshelf/bookshelf).
#
# This source code is subject to the terms of the Mozilla Public License, v. 2.0.
# If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
#
# Conditions:
# - You may use this file in compliance with the MPL v2.0
# - Any modifications must be documented and disclosed under the same license
#
# For more details, refer to the MPL v2.0.
# ------------------------------------------------------------------------------------------------------------

scoreboard objectives add bs.data dummy [{text:"BS ",color:"dark_gray"},{text:"Data",color:"aqua"}]
scoreboard objectives add bs.out dummy [{text:"BS ",color:"dark_gray"},{text:"Output",color:"aqua"}]
scoreboard objectives add bs.ctx dummy [{text:"BS ",color:"dark_gray"},{text:"Ctx",color:"aqua"}]
scoreboard objectives add bs.const dummy [{text:"BS ",color:"dark_gray"},{text:"Const",color:"aqua"}]

scoreboard players set 8 bs.const 8

execute unless data storage bs:const log.messages[{namespaces:["bs.string"]}] run data modify storage bs:const log.messages[{namespaces:["bs"]}].namespaces append value "bs.string"

function bs.string:import/char_table
