# ------------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Gunivers
#
# This file is part of the Bookshelf project (https://github.com/mcbookshelf/bookshelf).
#
# This source code is subject to the terms of the Mozilla Public License, v. 2.0.
# If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
#
# Conditions:
# - You may use this file in compliance with the MPL v2.0
# - Any modifications must be documented and disclosed under the same license
#
# For more details, refer to the MPL v2.0.
# ------------------------------------------------------------------------------------------------------------

$data modify storage bs:ctx _.test set string storage bs:ctx _.str 0 $(y)
data modify storage bs:ctx _.ltr set string storage bs:ctx _.test -1
execute store success score #t bs.ctx run data modify storage bs:ctx _.test set from storage bs:ctx _.substr

execute if score #t bs.ctx matches 0 run function bs.string:find/recurse/found
execute unless score #o bs.ctx matches ..-1 if score #t bs.ctx matches 0 if score #c bs.ctx >= #o bs.ctx run return 1

function bs.string:utils/skip_table/match with storage bs:ctx _

scoreboard players operation #i bs.ctx += #z bs.ctx
execute if score #l bs.ctx < #i bs.ctx run return 1

function bs.string:find/recurse/substr with storage bs:ctx
function bs.string:find/recurse/next with storage bs:ctx
