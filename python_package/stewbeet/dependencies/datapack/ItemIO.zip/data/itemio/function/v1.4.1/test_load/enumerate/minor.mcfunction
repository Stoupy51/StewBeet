
execute if score #itemio.minor load.status matches ..4 unless score #itemio.minor load.status matches 4 run function itemio:v1.4.1/test_load/enumerate/set_version
execute unless score #itemio.set load.status matches 1 if score #itemio.minor load.status matches ..4 if score #itemio.minor load.status matches 4 run function itemio:v1.4.1/test_load/enumerate/patch
