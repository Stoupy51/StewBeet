
execute if entity @s[tag=!itemio.network.already_regenerated] run function itemio:v1.7.0/cable/destroy/regen
