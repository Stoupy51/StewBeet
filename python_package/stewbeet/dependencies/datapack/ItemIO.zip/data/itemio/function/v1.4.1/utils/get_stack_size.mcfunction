
execute if data entity @s equipment.mainhand.components."minecraft:max_stack_size" run return run data get entity @s equipment.mainhand.components."minecraft:max_stack_size"

execute if items entity @s weapon *[minecraft:max_stack_size=64] run return 64
execute if items entity @s weapon *[minecraft:max_stack_size=16] run return 16
execute if items entity @s weapon *[minecraft:max_stack_size=1] run return 1

execute if items entity @s weapon *[minecraft:max_stack_size=2] run return 2

execute if items entity @s weapon *[minecraft:max_stack_size=3] run return 3

execute if items entity @s weapon *[minecraft:max_stack_size=4] run return 4
execute if items entity @s weapon *[minecraft:max_stack_size=5] run return 5

execute if items entity @s weapon *[minecraft:max_stack_size=6] run return 6
execute if items entity @s weapon *[minecraft:max_stack_size=7] run return 7

execute if items entity @s weapon *[minecraft:max_stack_size=8] run return 8

execute if items entity @s weapon *[minecraft:max_stack_size=9] run return 9
execute if items entity @s weapon *[minecraft:max_stack_size=10] run return 10

execute if items entity @s weapon *[minecraft:max_stack_size=11] run return 11
execute if items entity @s weapon *[minecraft:max_stack_size=12] run return 12

execute if items entity @s weapon *[minecraft:max_stack_size=13] run return 13

execute if items entity @s weapon *[minecraft:max_stack_size=14] run return 14
execute if items entity @s weapon *[minecraft:max_stack_size=15] run return 15

execute if items entity @s weapon *[minecraft:max_stack_size=17] run return 17
execute if items entity @s weapon *[minecraft:max_stack_size=18] run return 18

execute if items entity @s weapon *[minecraft:max_stack_size=19] run return 19

execute if items entity @s weapon *[minecraft:max_stack_size=20] run return 20
execute if items entity @s weapon *[minecraft:max_stack_size=21] run return 21

execute if items entity @s weapon *[minecraft:max_stack_size=22] run return 22
execute if items entity @s weapon *[minecraft:max_stack_size=23] run return 23

execute if items entity @s weapon *[minecraft:max_stack_size=24] run return 24

execute if items entity @s weapon *[minecraft:max_stack_size=25] run return 25
execute if items entity @s weapon *[minecraft:max_stack_size=26] run return 26

execute if items entity @s weapon *[minecraft:max_stack_size=27] run return 27
execute if items entity @s weapon *[minecraft:max_stack_size=28] run return 28

execute if items entity @s weapon *[minecraft:max_stack_size=29] run return 29

execute if items entity @s weapon *[minecraft:max_stack_size=30] run return 30
execute if items entity @s weapon *[minecraft:max_stack_size=31] run return 31

execute if items entity @s weapon *[minecraft:max_stack_size=32] run return 32
execute if items entity @s weapon *[minecraft:max_stack_size=33] run return 33

execute if items entity @s weapon *[minecraft:max_stack_size=34] run return 34

execute if items entity @s weapon *[minecraft:max_stack_size=35] run return 35
execute if items entity @s weapon *[minecraft:max_stack_size=36] run return 36

execute if items entity @s weapon *[minecraft:max_stack_size=37] run return 37
execute if items entity @s weapon *[minecraft:max_stack_size=38] run return 38

execute if items entity @s weapon *[minecraft:max_stack_size=39] run return 39

execute if items entity @s weapon *[minecraft:max_stack_size=40] run return 40
execute if items entity @s weapon *[minecraft:max_stack_size=41] run return 41

execute if items entity @s weapon *[minecraft:max_stack_size=42] run return 42
execute if items entity @s weapon *[minecraft:max_stack_size=43] run return 43

execute if items entity @s weapon *[minecraft:max_stack_size=44] run return 44

execute if items entity @s weapon *[minecraft:max_stack_size=45] run return 45
execute if items entity @s weapon *[minecraft:max_stack_size=46] run return 46

execute if items entity @s weapon *[minecraft:max_stack_size=47] run return 47
execute if items entity @s weapon *[minecraft:max_stack_size=48] run return 48

execute if items entity @s weapon *[minecraft:max_stack_size=49] run return 49

execute if items entity @s weapon *[minecraft:max_stack_size=50] run return 50
execute if items entity @s weapon *[minecraft:max_stack_size=51] run return 51

execute if items entity @s weapon *[minecraft:max_stack_size=52] run return 52
execute if items entity @s weapon *[minecraft:max_stack_size=53] run return 53

execute if items entity @s weapon *[minecraft:max_stack_size=54] run return 54

execute if items entity @s weapon *[minecraft:max_stack_size=55] run return 55
execute if items entity @s weapon *[minecraft:max_stack_size=56] run return 56

execute if items entity @s weapon *[minecraft:max_stack_size=57] run return 57
execute if items entity @s weapon *[minecraft:max_stack_size=58] run return 58

execute if items entity @s weapon *[minecraft:max_stack_size=59] run return 59

execute if items entity @s weapon *[minecraft:max_stack_size=60] run return 60
execute if items entity @s weapon *[minecraft:max_stack_size=61] run return 61

execute if items entity @s weapon *[minecraft:max_stack_size=62] run return 62
execute if items entity @s weapon *[minecraft:max_stack_size=63] run return 63

execute if items entity @s weapon *[minecraft:max_stack_size=65] run return 65

execute if items entity @s weapon *[minecraft:max_stack_size=66] run return 66
execute if items entity @s weapon *[minecraft:max_stack_size=67] run return 67

execute if items entity @s weapon *[minecraft:max_stack_size=68] run return 68
execute if items entity @s weapon *[minecraft:max_stack_size=69] run return 69

execute if items entity @s weapon *[minecraft:max_stack_size=70] run return 70

execute if items entity @s weapon *[minecraft:max_stack_size=71] run return 71
execute if items entity @s weapon *[minecraft:max_stack_size=72] run return 72

execute if items entity @s weapon *[minecraft:max_stack_size=73] run return 73
execute if items entity @s weapon *[minecraft:max_stack_size=74] run return 74

execute if items entity @s weapon *[minecraft:max_stack_size=75] run return 75

execute if items entity @s weapon *[minecraft:max_stack_size=76] run return 76
execute if items entity @s weapon *[minecraft:max_stack_size=77] run return 77

execute if items entity @s weapon *[minecraft:max_stack_size=78] run return 78
execute if items entity @s weapon *[minecraft:max_stack_size=79] run return 79

execute if items entity @s weapon *[minecraft:max_stack_size=80] run return 80

execute if items entity @s weapon *[minecraft:max_stack_size=81] run return 81
execute if items entity @s weapon *[minecraft:max_stack_size=82] run return 82

execute if items entity @s weapon *[minecraft:max_stack_size=83] run return 83
execute if items entity @s weapon *[minecraft:max_stack_size=84] run return 84

execute if items entity @s weapon *[minecraft:max_stack_size=85] run return 85

execute if items entity @s weapon *[minecraft:max_stack_size=86] run return 86
execute if items entity @s weapon *[minecraft:max_stack_size=87] run return 87

execute if items entity @s weapon *[minecraft:max_stack_size=88] run return 88
execute if items entity @s weapon *[minecraft:max_stack_size=89] run return 89

execute if items entity @s weapon *[minecraft:max_stack_size=90] run return 90

execute if items entity @s weapon *[minecraft:max_stack_size=91] run return 91
execute if items entity @s weapon *[minecraft:max_stack_size=92] run return 92

execute if items entity @s weapon *[minecraft:max_stack_size=93] run return 93
execute if items entity @s weapon *[minecraft:max_stack_size=94] run return 94

execute if items entity @s weapon *[minecraft:max_stack_size=95] run return 95

execute if items entity @s weapon *[minecraft:max_stack_size=96] run return 96
execute if items entity @s weapon *[minecraft:max_stack_size=97] run return 97

execute if items entity @s weapon *[minecraft:max_stack_size=98] run return 98
execute if items entity @s weapon *[minecraft:max_stack_size=99] run return 99

return 1
