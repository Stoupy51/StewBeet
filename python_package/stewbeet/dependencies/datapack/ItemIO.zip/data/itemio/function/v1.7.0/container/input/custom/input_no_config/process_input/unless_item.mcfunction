
scoreboard players set #success_input itemio.io 1

scoreboard players set #full_stack itemio.math.input 64

data remove storage itemio:main get_stack_size
data modify storage itemio:main get_stack_size set from storage itemio:main.input input
execute store result score #full_stack itemio.math.input run function itemio:v1.7.0/utils/get_stack_size
scoreboard players set #config_max_stack_size itemio.math.input 2147483647
execute if data storage itemio:main.input ioconfig[0].max_stack_size store result score #config_max_stack_size itemio.math.input run data get storage itemio:main.input ioconfig[0].max_stack_size
execute if score #full_stack itemio.math.input > #config_max_stack_size itemio.math.input run scoreboard players operation #full_stack itemio.math.input = #config_max_stack_size itemio.math.input

$data modify storage itemio:main.input input.Slot set value $(Slot)b

execute store result score #count_input itemio.math.input run data get storage itemio:main.input input.count

scoreboard players set #new_count_input itemio.math.input 0
execute if score #count_input itemio.math.input <= #full_stack itemio.math.input run function itemio:v1.7.0/container/input/custom/input_no_config/process_input/unless_item/inf

execute if score #count_input itemio.math.input > #full_stack itemio.math.input run function itemio:v1.7.0/container/input/custom/input_no_config/process_input/unless_item/sup
