
execute as @a[tag=convention.debug] run function itemio:v1.4.1/print_version
schedule clear itemio:v1.4.1/load_2
