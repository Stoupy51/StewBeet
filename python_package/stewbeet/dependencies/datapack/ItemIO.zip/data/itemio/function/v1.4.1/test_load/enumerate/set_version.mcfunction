
scoreboard players set #itemio.major load.status 1
scoreboard players set #itemio.minor load.status 4
scoreboard players set #itemio.patch load.status 1
scoreboard players set #itemio.set load.status 1
