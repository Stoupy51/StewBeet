
# @public

execute if entity @s[type=#itemio:servos, tag=itemio.servo] at @s run function itemio:v1.7.0/servo/init
