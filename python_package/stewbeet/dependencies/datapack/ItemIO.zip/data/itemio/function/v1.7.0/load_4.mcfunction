
execute as @a[tag=convention.debug] run function itemio:v1.7.0/print_version
schedule clear itemio:v1.7.0/load_2
