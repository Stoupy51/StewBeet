
# @public

execute if entity @s[type=#itemio:servos] at @s run function itemio:v1.4.1/servo/init
