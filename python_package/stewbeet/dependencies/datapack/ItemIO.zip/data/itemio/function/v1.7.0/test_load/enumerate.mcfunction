
scoreboard players reset #itemio.set load.status
scoreboard players add #itemio.major load.status 0
scoreboard players add #itemio.minor load.status 0
scoreboard players add #itemio.patch load.status 0
function itemio:v1.7.0/test_load/enumerate/major
