
# @public

execute if entity @s[type=#itemio:container] run function itemio:v1.4.1/container/init
