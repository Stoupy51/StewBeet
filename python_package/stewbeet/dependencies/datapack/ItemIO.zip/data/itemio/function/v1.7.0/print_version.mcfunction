
tellraw @s [{text: "[Loaded ItemIO v1.7.0]", color: "green"}]
