
scoreboard players set #nbt_items itemio.math.input 0
execute if data storage itemio:io input run function itemio:v1.4.1/container/input/vanilla/input
