
tellraw @s [{text: "[Loaded ItemIO v1.4.1-216afba]", color: "green"}]
