
$execute if entity @s[tag=itemio.container.nbt_items.on_passengers] on passengers store result $(nbt_items_path)[{Slot:$(Slot)b}].count int 1 run scoreboard players get #full_stack itemio.math.input
$execute if entity @s[tag=itemio.container.nbt_items.on_vehicle] on vehicle store result $(nbt_items_path)[{Slot:$(Slot)b}].count int 1 run scoreboard players get #full_stack itemio.math.input
$execute if entity @s[tag=!itemio.container.nbt_items.on_vehicle,tag=!itemio.container.nbt_items.on_passengers] store result $(nbt_items_path)[{Slot:$(Slot)b}].count int 1 run scoreboard players get #full_stack itemio.math.input
