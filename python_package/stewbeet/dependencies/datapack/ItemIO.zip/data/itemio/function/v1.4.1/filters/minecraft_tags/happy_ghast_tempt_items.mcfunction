
scoreboard players set #filter.valid_item itemio.io 0
data modify entity @s equipment.mainhand set value {}
data modify entity @s equipment.mainhand set from storage itemio:io item
execute if predicate itemio:v1.4.1/minecraft/happy_ghast_tempt_items run scoreboard players set #filter.valid_item itemio.io 1
