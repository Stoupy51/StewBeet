schedule clear smithed.actionbar:v0.6.6/technical/tick
execute if score #smithed.actionbar.major load.status matches 0 if score #smithed.actionbar.minor load.status matches 6 if score #smithed.actionbar.patch load.status matches 6 run function smithed.actionbar:v0.6.6/technical/load
