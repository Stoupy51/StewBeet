scoreboard players set #smithed.actionbar.major load.status 0
scoreboard players set #smithed.actionbar.minor load.status 7
scoreboard players set #smithed.actionbar.patch load.status 0
scoreboard players set #smithed.actionbar.set load.status 1
