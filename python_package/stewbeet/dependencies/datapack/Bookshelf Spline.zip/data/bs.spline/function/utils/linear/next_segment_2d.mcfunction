# ------------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Gunivers
#
# This file is part of the Bookshelf project (https://github.com/mcbookshelf/bookshelf).
#
# This source code is subject to the terms of the Mozilla Public License, v. 2.0.
# If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
#
# Conditions:
# - You may use this file in compliance with the MPL v2.0
# - Any modifications must be documented and disclosed under the same license
#
# For more details, refer to the MPL v2.0.
# ------------------------------------------------------------------------------------------------------------

data modify storage bs:lambda spline.point set value [0d,0d]
execute store result score #x bs.ctx \
  store result score #y bs.ctx \
  run scoreboard players operation #t bs.ctx %= 1000 bs.const

execute store result score #a bs.ctx run data get storage bs:ctx _.points[0][0] 1000
execute store result score #b bs.ctx run data get storage bs:ctx _.points[1][0] 1000

execute store result score #e bs.ctx run data get storage bs:ctx _.points[0][1] 1000
execute store result score #f bs.ctx run data get storage bs:ctx _.points[1][1] 1000

# Compute Lerp coefficients
execute store result score #c bs.ctx \
  store result score #d bs.ctx \
  store result score #g bs.ctx \
  run scoreboard players set #h bs.ctx 0
scoreboard players operation #b bs.ctx -= #a bs.ctx
scoreboard players operation #f bs.ctx -= #e bs.ctx

data remove storage bs:ctx _.points[0]
