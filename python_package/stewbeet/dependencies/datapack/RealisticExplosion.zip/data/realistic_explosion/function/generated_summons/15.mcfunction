
#> realistic_explosion:generated_summons/15
#
# @executed	as @e[type=item,tag=!realistic_explosion.old] & at @s
#
# @within	realistic_explosion:generated_summons/on_item
#

execute if data storage realistic_explosion:main {id:"minecraft:anvil"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:anvil"}}
execute if data storage realistic_explosion:main {id:"minecraft:chest"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:chest"}}
execute if data storage realistic_explosion:main {id:"minecraft:glass"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:glass"}}
execute if data storage realistic_explosion:main {id:"minecraft:lever"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:lever"}}
execute if data storage realistic_explosion:main {id:"minecraft:light"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:light"}}
execute if data storage realistic_explosion:main {id:"minecraft:lilac"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:lilac"}}
execute if data storage realistic_explosion:main {id:"minecraft:melon"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:melon"}}
execute if data storage realistic_explosion:main {id:"minecraft:peony"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:peony"}}
execute if data storage realistic_explosion:main {id:"minecraft:poppy"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:poppy"}}
execute if data storage realistic_explosion:main {id:"minecraft:sculk"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:sculk"}}
execute if data storage realistic_explosion:main {id:"minecraft:stone"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:stone"}}
execute if data storage realistic_explosion:main {id:"minecraft:torch"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:torch"}}
execute if data storage realistic_explosion:main {id:"minecraft:vault"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:vault"}}
execute if data storage realistic_explosion:main {id:"minecraft:wheat"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:wheat"}}
execute if data storage realistic_explosion:main {id:"minecraft:water"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:water"}}

