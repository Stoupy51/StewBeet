
#> realistic_explosion:generated_summons/37
#
# @executed	as @e[type=item,tag=!realistic_explosion.old] & at @s
#
# @within	realistic_explosion:generated_summons/on_item
#

execute if data storage realistic_explosion:main {id:"minecraft:exposed_copper_golem_statue"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:exposed_copper_golem_statue"}}
execute if data storage realistic_explosion:main {id:"minecraft:infested_mossy_stone_bricks"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:infested_mossy_stone_bricks"}}
execute if data storage realistic_explosion:main {id:"minecraft:smooth_red_sandstone_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:smooth_red_sandstone_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_exposed_lightning_rod"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:waxed_exposed_lightning_rod"}}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_oxidized_copper_chain"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:waxed_oxidized_copper_chain"}}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_oxidized_copper_chest"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:waxed_oxidized_copper_chest"}}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_oxidized_copper_grate"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:waxed_oxidized_copper_grate"}}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_weathered_copper_bars"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:waxed_weathered_copper_bars"}}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_weathered_copper_bulb"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:waxed_weathered_copper_bulb"}}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_weathered_copper_door"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:waxed_weathered_copper_door"}}
execute if data storage realistic_explosion:main {id:"minecraft:weathered_cut_copper_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:weathered_cut_copper_stairs"}}

