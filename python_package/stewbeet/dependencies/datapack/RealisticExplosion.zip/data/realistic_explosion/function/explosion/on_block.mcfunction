
#> realistic_explosion:explosion/on_block
#
# @executed	positioned ~-2 ~-1 ~-1
#
# @within	realistic_explosion:explosion/main [ positioned ~-2 ~-1 ~-1 ]
#			realistic_explosion:explosion/main [ positioned ~-2 ~-1 ~0 ]
#			realistic_explosion:explosion/main [ positioned ~-2 ~-1 ~1 ]
#			realistic_explosion:explosion/main [ positioned ~-2 ~0 ~-1 ]
#			realistic_explosion:explosion/main [ positioned ~-2 ~0 ~0 ]
#			realistic_explosion:explosion/main [ positioned ~-2 ~0 ~1 ]
#			realistic_explosion:explosion/main [ positioned ~-2 ~1 ~-1 ]
#			realistic_explosion:explosion/main [ positioned ~-2 ~1 ~0 ]
#			realistic_explosion:explosion/main [ positioned ~-2 ~1 ~1 ]
#			realistic_explosion:explosion/main [ positioned ~-1 ~-2 ~-1 ]
#			realistic_explosion:explosion/main [ positioned ~-1 ~-2 ~0 ]
#			realistic_explosion:explosion/main [ positioned ~-1 ~-2 ~1 ]
#			realistic_explosion:explosion/main [ positioned ~-1 ~-1 ~-2 ]
#			realistic_explosion:explosion/main [ positioned ~-1 ~-1 ~2 ]
#			realistic_explosion:explosion/main [ positioned ~-1 ~0 ~-2 ]
#			realistic_explosion:explosion/main [ positioned ~-1 ~0 ~2 ]
#			realistic_explosion:explosion/main [ positioned ~-1 ~1 ~-2 ]
#			realistic_explosion:explosion/main [ positioned ~-1 ~1 ~2 ]
#			realistic_explosion:explosion/main [ positioned ~-1 ~2 ~-1 ]
#			realistic_explosion:explosion/main [ positioned ~-1 ~2 ~0 ]
#			realistic_explosion:explosion/main [ positioned ~-1 ~2 ~1 ]
#			realistic_explosion:explosion/main [ positioned ~0 ~-2 ~-1 ]
#			realistic_explosion:explosion/main [ positioned ~0 ~-2 ~0 ]
#			realistic_explosion:explosion/main [ positioned ~0 ~-2 ~1 ]
#			realistic_explosion:explosion/main [ positioned ~0 ~-1 ~-2 ]
#			realistic_explosion:explosion/main [ positioned ~0 ~-1 ~2 ]
#			realistic_explosion:explosion/main [ positioned ~0 ~0 ~-2 ]
#			realistic_explosion:explosion/main [ positioned ~0 ~0 ~2 ]
#			realistic_explosion:explosion/main [ positioned ~0 ~1 ~-2 ]
#			realistic_explosion:explosion/main [ positioned ~0 ~1 ~2 ]
#			realistic_explosion:explosion/main [ positioned ~0 ~2 ~-1 ]
#			realistic_explosion:explosion/main [ positioned ~0 ~2 ~0 ]
#			realistic_explosion:explosion/main [ positioned ~0 ~2 ~1 ]
#			realistic_explosion:explosion/main [ positioned ~1 ~-2 ~-1 ]
#			realistic_explosion:explosion/main [ positioned ~1 ~-2 ~0 ]
#			realistic_explosion:explosion/main [ positioned ~1 ~-2 ~1 ]
#			realistic_explosion:explosion/main [ positioned ~1 ~-1 ~-2 ]
#			realistic_explosion:explosion/main [ positioned ~1 ~-1 ~2 ]
#			realistic_explosion:explosion/main [ positioned ~1 ~0 ~-2 ]
#			realistic_explosion:explosion/main [ positioned ~1 ~0 ~2 ]
#			realistic_explosion:explosion/main [ positioned ~1 ~1 ~-2 ]
#			realistic_explosion:explosion/main [ positioned ~1 ~1 ~2 ]
#			realistic_explosion:explosion/main [ positioned ~1 ~2 ~-1 ]
#			realistic_explosion:explosion/main [ positioned ~1 ~2 ~0 ]
#			realistic_explosion:explosion/main [ positioned ~1 ~2 ~1 ]
#			realistic_explosion:explosion/main [ positioned ~2 ~-1 ~-1 ]
#			realistic_explosion:explosion/main [ positioned ~2 ~-1 ~0 ]
#			realistic_explosion:explosion/main [ positioned ~2 ~-1 ~1 ]
#			realistic_explosion:explosion/main [ positioned ~2 ~0 ~-1 ]
#			realistic_explosion:explosion/main [ positioned ~2 ~0 ~0 ]
#			realistic_explosion:explosion/main [ positioned ~2 ~0 ~1 ]
#			realistic_explosion:explosion/main [ positioned ~2 ~1 ~-1 ]
#			realistic_explosion:explosion/main [ positioned ~2 ~1 ~0 ]
#			realistic_explosion:explosion/main [ positioned ~2 ~1 ~1 ]
#
# @input score		#power_state realistic_explosion.data : the power state of the explosion (0, 1, 2 or 3)
# 
# @description		Destroys the block if it can be destroyed by the explosion
#

# Depending on the power of the explosion, execute the correct setblock command
execute if score #power_state realistic_explosion.data matches 0 if block ~ ~ ~ #realistic_explosion:no_blast_resistance run setblock ~ ~ ~ air destroy
execute if score #power_state realistic_explosion.data matches 1 if block ~ ~ ~ #realistic_explosion:equal_and_below_1200 run setblock ~ ~ ~ air destroy
execute if score #power_state realistic_explosion.data matches 2 if block ~ ~ ~ #realistic_explosion:equal_and_below_3600000 run setblock ~ ~ ~ air destroy
execute if score #power_state realistic_explosion.data matches 3 if block ~ ~ ~ #realistic_explosion:all run setblock ~ ~ ~ air destroy

