# ------------------------------------------------------------------------------------------------------------
# Copyright (c) 2025 Gunivers
#
# This file is part of the Bookshelf project (https://github.com/mcbookshelf/bookshelf).
#
# This source code is subject to the terms of the Mozilla Public License, v. 2.0.
# If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
#
# Conditions:
# - You may use this file in compliance with the MPL v2.0
# - Any modifications must be documented and disclosed under the same license
#
# For more details, refer to the MPL v2.0.
# ------------------------------------------------------------------------------------------------------------

data remove storage bs:ctx _.executor
$execute store result score #i bs.ctx run tag $(selector) add bs.interaction.this
loot replace entity B5-0-0-0-3 contents loot {pools:[{rolls:1,entries:[{type:"item",name:"stone",functions:[{function:"set_name",entity:"this",name:{"selector":"@n[tag=bs.interaction.this]"}}]}]}]}
data modify storage bs:ctx _.executor set from entity B5-0-0-0-3 item.components.minecraft:custom_name.insertion
tag @e[tag=bs.interaction.this] remove bs.interaction.this
