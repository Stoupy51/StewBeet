

tellraw @a [{"text": "Made of ", "color": "gray", "italic": False}]
tellraw @a ["Steel ingot 16: ",{"render": "steel_ingot", "height": 16}, "\n"]
tellraw @a ["Stone: ",{"render": "minecraft:stone"}, "\n"]
tellraw @a ["Tin ore: ",{"render": "mechanization:tin_ore", "height": 24, "ascent": 12}, "\n\n"]

# A high-resolution texture shown small: 32px stored, 8px tall on screen
tellraw @a ["Low res steel ingot: ",{"render": "steel_ingot", "height": 16, "resolution": 8}, "\n\n"]

# Same item, height and resolution, but a different ascent: two glyphs, one texture
tellraw @a [{"render": "steel_ingot", "height": 8, "resolution": 32, "ascent": 2}, "\n"]

# Finally, the pack icon
tellraw @a ["\n\n\n\n",{"render": "ICON","height": 64}, "\n\n\n\n"]

