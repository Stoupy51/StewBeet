
#> furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/try_place_marker
#
# @executed	positioned ~-8 ~ ~-8
#
# @within	furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-8 ~ ~-8 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-8 ~ ~-7 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-8 ~ ~-6 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-8 ~ ~-5 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-8 ~ ~-4 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-8 ~ ~-3 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-8 ~ ~-2 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-8 ~ ~-1 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-8 ~ ~00 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-8 ~ ~01 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-8 ~ ~02 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-8 ~ ~03 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-8 ~ ~04 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-8 ~ ~05 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-8 ~ ~06 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-8 ~ ~07 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-8 ~ ~08 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-7 ~ ~-8 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-7 ~ ~-7 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-7 ~ ~-6 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-7 ~ ~-5 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-7 ~ ~-4 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-7 ~ ~-3 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-7 ~ ~-2 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-7 ~ ~-1 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-7 ~ ~00 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-7 ~ ~01 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-7 ~ ~02 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-7 ~ ~03 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-7 ~ ~04 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-7 ~ ~05 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-7 ~ ~06 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-7 ~ ~07 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-7 ~ ~08 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-6 ~ ~-8 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-6 ~ ~-7 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-6 ~ ~-6 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-6 ~ ~-5 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-6 ~ ~-4 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-6 ~ ~-3 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-6 ~ ~-2 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-6 ~ ~-1 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-6 ~ ~00 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-6 ~ ~01 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-6 ~ ~02 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-6 ~ ~03 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-6 ~ ~04 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-6 ~ ~05 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-6 ~ ~06 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-6 ~ ~07 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-6 ~ ~08 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-5 ~ ~-8 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-5 ~ ~-7 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-5 ~ ~-6 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-5 ~ ~-5 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-5 ~ ~-4 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-5 ~ ~-3 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-5 ~ ~-2 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-5 ~ ~-1 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-5 ~ ~00 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-5 ~ ~01 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-5 ~ ~02 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-5 ~ ~03 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-5 ~ ~04 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-5 ~ ~05 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-5 ~ ~06 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-5 ~ ~07 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-5 ~ ~08 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-4 ~ ~-8 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-4 ~ ~-7 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-4 ~ ~-6 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-4 ~ ~-5 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-4 ~ ~-4 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-4 ~ ~-3 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-4 ~ ~-2 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-4 ~ ~-1 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-4 ~ ~00 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-4 ~ ~01 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-4 ~ ~02 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-4 ~ ~03 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-4 ~ ~04 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-4 ~ ~05 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-4 ~ ~06 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-4 ~ ~07 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-4 ~ ~08 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-3 ~ ~-8 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-3 ~ ~-7 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-3 ~ ~-6 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-3 ~ ~-5 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-3 ~ ~-4 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-3 ~ ~-3 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-3 ~ ~-2 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-3 ~ ~-1 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-3 ~ ~00 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-3 ~ ~01 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-3 ~ ~02 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-3 ~ ~03 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-3 ~ ~04 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-3 ~ ~05 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-3 ~ ~06 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-3 ~ ~07 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-3 ~ ~08 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-2 ~ ~-8 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-2 ~ ~-7 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-2 ~ ~-6 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-2 ~ ~-5 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-2 ~ ~-4 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-2 ~ ~-3 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-2 ~ ~-2 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-2 ~ ~-1 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-2 ~ ~00 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-2 ~ ~01 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-2 ~ ~02 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-2 ~ ~03 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-2 ~ ~04 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-2 ~ ~05 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-2 ~ ~06 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-2 ~ ~07 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-2 ~ ~08 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-1 ~ ~-8 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-1 ~ ~-7 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-1 ~ ~-6 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-1 ~ ~-5 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-1 ~ ~-4 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-1 ~ ~-3 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-1 ~ ~-2 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-1 ~ ~-1 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-1 ~ ~00 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-1 ~ ~01 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-1 ~ ~02 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-1 ~ ~03 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-1 ~ ~04 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-1 ~ ~05 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-1 ~ ~06 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-1 ~ ~07 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~-1 ~ ~08 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~0 ~ ~-8 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~0 ~ ~-7 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~0 ~ ~-6 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~0 ~ ~-5 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~0 ~ ~-4 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~0 ~ ~-3 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~0 ~ ~-2 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~0 ~ ~-1 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~0 ~ ~00 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~0 ~ ~01 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~0 ~ ~02 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~0 ~ ~03 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~0 ~ ~04 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~0 ~ ~05 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~0 ~ ~06 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~0 ~ ~07 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~0 ~ ~08 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~8 ~ ~-8 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~8 ~ ~-7 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~8 ~ ~-6 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~8 ~ ~-5 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~8 ~ ~-4 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~8 ~ ~-3 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~8 ~ ~-2 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~8 ~ ~-1 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~8 ~ ~00 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~8 ~ ~01 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~8 ~ ~02 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~8 ~ ~03 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~8 ~ ~04 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~8 ~ ~05 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~8 ~ ~06 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~8 ~ ~07 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~8 ~ ~08 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~7 ~ ~-8 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~7 ~ ~-7 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~7 ~ ~-6 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~7 ~ ~-5 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~7 ~ ~-4 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~7 ~ ~-3 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~7 ~ ~-2 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~7 ~ ~-1 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~7 ~ ~00 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~7 ~ ~01 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~7 ~ ~02 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~7 ~ ~03 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~7 ~ ~04 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~7 ~ ~05 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~7 ~ ~06 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~7 ~ ~07 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~7 ~ ~08 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~6 ~ ~-8 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~6 ~ ~-7 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~6 ~ ~-6 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~6 ~ ~-5 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~6 ~ ~-4 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~6 ~ ~-3 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~6 ~ ~-2 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~6 ~ ~-1 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~6 ~ ~00 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~6 ~ ~01 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~6 ~ ~02 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~6 ~ ~03 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~6 ~ ~04 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~6 ~ ~05 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~6 ~ ~06 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~6 ~ ~07 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~6 ~ ~08 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~5 ~ ~-8 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~5 ~ ~-7 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~5 ~ ~-6 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~5 ~ ~-5 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~5 ~ ~-4 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~5 ~ ~-3 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~5 ~ ~-2 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~5 ~ ~-1 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~5 ~ ~00 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~5 ~ ~01 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~5 ~ ~02 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~5 ~ ~03 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~5 ~ ~04 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~5 ~ ~05 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~5 ~ ~06 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~5 ~ ~07 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~5 ~ ~08 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~4 ~ ~-8 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~4 ~ ~-7 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~4 ~ ~-6 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~4 ~ ~-5 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~4 ~ ~-4 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~4 ~ ~-3 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~4 ~ ~-2 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~4 ~ ~-1 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~4 ~ ~00 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~4 ~ ~01 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~4 ~ ~02 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~4 ~ ~03 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~4 ~ ~04 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~4 ~ ~05 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~4 ~ ~06 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~4 ~ ~07 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~4 ~ ~08 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~3 ~ ~-8 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~3 ~ ~-7 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~3 ~ ~-6 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~3 ~ ~-5 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~3 ~ ~-4 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~3 ~ ~-3 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~3 ~ ~-2 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~3 ~ ~-1 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~3 ~ ~00 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~3 ~ ~01 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~3 ~ ~02 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~3 ~ ~03 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~3 ~ ~04 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~3 ~ ~05 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~3 ~ ~06 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~3 ~ ~07 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~3 ~ ~08 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~2 ~ ~-8 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~2 ~ ~-7 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~2 ~ ~-6 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~2 ~ ~-5 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~2 ~ ~-4 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~2 ~ ~-3 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~2 ~ ~-2 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~2 ~ ~-1 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~2 ~ ~00 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~2 ~ ~01 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~2 ~ ~02 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~2 ~ ~03 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~2 ~ ~04 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~2 ~ ~05 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~2 ~ ~06 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~2 ~ ~07 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~2 ~ ~08 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~1 ~ ~-8 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~1 ~ ~-7 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~1 ~ ~-6 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~1 ~ ~-5 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~1 ~ ~-4 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~1 ~ ~-3 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~1 ~ ~-2 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~1 ~ ~-1 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~1 ~ ~00 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~1 ~ ~01 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~1 ~ ~02 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~1 ~ ~03 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~1 ~ ~04 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~1 ~ ~05 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~1 ~ ~06 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~1 ~ ~07 ]
#			furnace_nbt_recipes:v1.10.1/advancements/check_for_furnaces/look_layer [ positioned ~1 ~ ~08 ]
#

execute align xyz positioned ~.5 ~ ~.5 unless entity @e[type=marker,dx=-1,dy=-1,dz=-1,tag=furnace_nbt_recipes.furnace] run summon marker ~ ~ ~ {Tags:["furnace_nbt_recipes.furnace"]}

