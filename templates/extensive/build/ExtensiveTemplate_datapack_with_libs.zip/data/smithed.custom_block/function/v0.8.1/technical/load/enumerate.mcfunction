scoreboard players reset #smithed.custom_block.set load.status
scoreboard players add #smithed.custom_block.major load.status 0
scoreboard players add #smithed.custom_block.minor load.status 0
scoreboard players add #smithed.custom_block.patch load.status 0
function smithed.custom_block:v0.8.1/technical/load/enumerate/major
