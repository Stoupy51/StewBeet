scoreboard players set #smithed.custom_block.major load.status 0
scoreboard players set #smithed.custom_block.minor load.status 11
scoreboard players set #smithed.custom_block.patch load.status 0
scoreboard players set #smithed.custom_block.set load.status 1
