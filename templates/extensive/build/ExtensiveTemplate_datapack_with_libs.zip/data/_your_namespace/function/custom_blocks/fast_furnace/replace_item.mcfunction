
#> _your_namespace:custom_blocks/fast_furnace/replace_item
#
# @executed	as @n[type=item,nbt={Item:{id:"minecraft:furnace"}},distance=..1]
#
# @within	_your_namespace:custom_blocks/fast_furnace/destroy [ as @n[type=item,nbt={Item:{id:"minecraft:furnace"}},distance=..1] ]
#

# Replace the item with the custom one
data modify entity @s Item.components set from storage _your_namespace:items all.fast_furnace.components
data modify entity @s Item.id set from storage _your_namespace:items all.fast_furnace.id

