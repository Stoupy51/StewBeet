# @public

execute if entity @s[tag=smithed.crafter] run function smithed.crafter:v0.11.0/block/table/tick
