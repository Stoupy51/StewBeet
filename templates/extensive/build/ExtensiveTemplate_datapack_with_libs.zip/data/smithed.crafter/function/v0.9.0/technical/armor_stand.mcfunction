# @public

execute if entity @s[tag=smithed.crafter] run function smithed.crafter:v0.9.0/block/table/tick
