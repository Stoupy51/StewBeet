execute as @e[tag=smithed.crafter] at @s run function smithed.crafter:v0.8.1/block/table/tick

schedule function smithed.crafter:v0.8.1/technical/tick 1 replace
