# @public

execute if data storage smithed.custom_block:main {blockApi: {id: "smithed:crafter"}} run function smithed.crafter:v0.8.1/block/table/place
