
#> common_signals:v0.2.2/unload
#
# @within	#common_signals:unload
#

# Remove scoreboard objectives
scoreboard objectives remove common_signals.data
scoreboard objectives remove load.status

