
#> common_signals:v0.2.2/load/set_items_storage
#
# @within	common_signals:v0.2.2/load/confirm_load
#


